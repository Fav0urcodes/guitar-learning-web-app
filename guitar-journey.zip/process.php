<?php
/**
 * Guitar Journey - process.php
 * PHP server-side form handler.
 *
 * Validates the contact form input, saves the submission to a text file,
 * and redirects back to index.html with a status parameter.
 *
 * Compatible with XAMPP / any standard PHP 7+ environment.
 */

// ── Only accept POST requests ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}

// ── Collect and sanitise form data ────────────────────────────────────────────
$name    = trim(strip_tags($_POST['name']    ?? ''));
$email   = trim(strip_tags($_POST['email']   ?? ''));
$subject = trim(strip_tags($_POST['subject'] ?? ''));
$message = trim(strip_tags($_POST['message'] ?? ''));

// ── Server-side validation ────────────────────────────────────────────────────
$errors = [];

if (empty($name)) {
    $errors[] = 'Name is required.';
} elseif (strlen($name) > 100) {
    $errors[] = 'Name must be 100 characters or fewer.';
}

if (empty($email)) {
    $errors[] = 'Email address is required.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address.';
}

if (strlen($subject) > 200) {
    $errors[] = 'Subject must be 200 characters or fewer.';
}

if (empty($message)) {
    $errors[] = 'Message is required.';
} elseif (strlen($message) < 20) {
    $errors[] = 'Message must be at least 20 characters.';
} elseif (strlen($message) > 2000) {
    $errors[] = 'Message must be 2,000 characters or fewer.';
}

// ── If validation fails, redirect back with error ─────────────────────────────
if (!empty($errors)) {
    $errorMsg = urlencode(implode(' | ', $errors));
    header('Location: index.html?page=contact&status=error&msg=' . $errorMsg);
    exit;
}

// ── Save submission to a text file ────────────────────────────────────────────
$submissionsFile = __DIR__ . '/submissions.txt';

$entry  = "=====================================\n";
$entry .= "Date      : " . date('Y-m-d H:i:s') . "\n";
$entry .= "Name      : " . $name . "\n";
$entry .= "Email     : " . $email . "\n";
$entry .= "Subject   : " . ($subject ?: '(none)') . "\n";
$entry .= "Message   :\n" . $message . "\n";
$entry .= "=====================================\n\n";

// Append to file (creates submissions.txt if it does not exist)
file_put_contents($submissionsFile, $entry, FILE_APPEND | LOCK_EX);

// ── Redirect back with success status ─────────────────────────────────────────
header('Location: index.html?page=contact&status=success');
exit;
?>
