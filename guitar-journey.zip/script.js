/**
 * Guitar Journey - script.js
 * Handles all interactivity:
 *   - Page navigation (tab switching)
 *   - Chord Trainer (SVG diagrams)
 *   - Guitar Quiz (8 questions, progress bar, leaderboard)
 *   - Contact Form (client-side validation + URL param messages)
 */

/* ============================================================
   NAVIGATION — switch between Home, Learn, Contact
   ============================================================ */

/**
 * Show a named page section and hide all others.
 * @param {string} pageId  - 'home' | 'learn' | 'contact'
 */
function showPage(pageId) {
  // Hide every page section
  document.querySelectorAll('.page-section').forEach(function (sec) {
    sec.classList.remove('active');
  });

  // Remove active highlight from every nav link
  document.querySelectorAll('.nav-link').forEach(function (link) {
    link.classList.remove('active');
  });

  // Show the requested section
  var target = document.getElementById('page-' + pageId);
  if (target) {
    target.classList.add('active');
  }

  // Highlight the matching nav links
  document.querySelectorAll('.nav-link[data-page="' + pageId + '"]').forEach(function (l) {
    l.classList.add('active');
  });

  // Scroll to top of page
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Update the URL hash without triggering a reload
  history.replaceState(null, '', '#' + pageId);
}

/** Toggle the mobile hamburger menu open/closed */
function toggleMobileMenu() {
  var menu = document.getElementById('mobileMenu');
  if (menu) {
    menu.classList.toggle('open');
  }
}

/* ── On page load: restore page from URL params and check for form status ── */
window.addEventListener('DOMContentLoaded', function () {
  // 1. Check ?page= query param to restore the correct tab
  var params  = new URLSearchParams(window.location.search);
  var page    = params.get('page') || 'home';
  var allowed = ['home', 'learn', 'contact'];
  if (!allowed.includes(page)) page = 'home';
  showPage(page);

  // 2. Check for form submission status from process.php redirect
  var status = params.get('status');
  var msgBox = document.getElementById('formMsg');

  if (msgBox && status === 'success') {
    msgBox.textContent = 'Your message was sent successfully! Thank you for reaching out.';
    msgBox.className   = 'form-msg success';
  } else if (msgBox && status === 'error') {
    var errDetail = params.get('msg') ? decodeURIComponent(params.get('msg')) : 'Please check your input and try again.';
    msgBox.textContent = 'Submission failed: ' + errDetail;
    msgBox.className   = 'form-msg error';
  }

  // 3. Initialise chord trainer and quiz
  selectChord('C');
  startQuiz();
  renderLeaderboard();
});


/* ============================================================
   CHORD TRAINER
   ============================================================ */

/**
 * Chord data.
 * string: 1 = high e, 6 = low E (standard notation)
 * positions: finger dot placements on the fretboard
 * openStrings: string numbers that ring open
 * mutedStrings: string numbers that are not played
 */
var CHORDS = {
  C: {
    fullName: 'C Major',
    positions: [
      { string: 2, fret: 1, finger: 1 },
      { string: 4, fret: 2, finger: 2 },
      { string: 5, fret: 3, finger: 3 }
    ],
    openStrings:  [1, 3],
    mutedStrings: [6],
    fingers: '1st finger  B string, fret 1\n2nd finger  D string, fret 2\n3rd finger  A string, fret 3',
    fact: 'C Major is the most common starting chord for beginners and features in thousands of popular songs.'
  },
  G: {
    fullName: 'G Major',
    positions: [
      { string: 6, fret: 3, finger: 2 },
      { string: 5, fret: 2, finger: 1 },
      { string: 1, fret: 3, finger: 3 }
    ],
    openStrings:  [2, 3, 4],
    mutedStrings: [],
    fingers: '1st finger  A string, fret 2\n2nd finger  Low E string, fret 3\n3rd finger  High e string, fret 3',
    fact: 'G Major has a bright, open sound. It is the cornerstone chord in folk, rock, and country music.'
  },
  D: {
    fullName: 'D Major',
    positions: [
      { string: 1, fret: 2, finger: 1 },
      { string: 3, fret: 2, finger: 2 },
      { string: 2, fret: 3, finger: 3 }
    ],
    openStrings:  [4],
    mutedStrings: [5, 6],
    fingers: '1st finger  High e string, fret 2\n2nd finger  G string, fret 2\n3rd finger  B string, fret 3',
    fact: 'D Major is essential for any beginner. Combined with G and Em you can play hundreds of songs right away!'
  },
  Em: {
    fullName: 'E Minor',
    positions: [
      { string: 5, fret: 2, finger: 2 },
      { string: 4, fret: 2, finger: 3 }
    ],
    openStrings:  [1, 2, 3, 6],
    mutedStrings: [],
    fingers: '2nd finger  A string, fret 2\n3rd finger  D string, fret 2',
    fact: 'E Minor is the easiest chord — only two fingers! It gives a brooding, emotional sound perfect for ballads.'
  },
  Am: {
    fullName: 'A Minor',
    positions: [
      { string: 2, fret: 1, finger: 1 },
      { string: 4, fret: 2, finger: 2 },
      { string: 3, fret: 2, finger: 3 }
    ],
    openStrings:  [1, 5],
    mutedStrings: [6],
    fingers: '1st finger  B string, fret 1\n2nd finger  D string, fret 2\n3rd finger  G string, fret 2',
    fact: 'A Minor has a melancholy, soulful quality. It pairs perfectly with C, G, and F in the classic Am–G–C–F progression.'
  },
  F: {
    fullName: 'F Major',
    positions: [
      { string: 1, fret: 1, finger: 1 },
      { string: 2, fret: 1, finger: 1 },
      { string: 3, fret: 2, finger: 2 },
      { string: 4, fret: 3, finger: 4 },
      { string: 5, fret: 3, finger: 3 }
    ],
    openStrings:  [],
    mutedStrings: [6],
    fingers: '1st finger  Barre strings 1–2, fret 1\n2nd finger  G string, fret 2\n3rd finger  A string, fret 3\n4th finger  D string, fret 3',
    fact: 'F Major is called the "beginner\'s wall" — its barre technique is challenging, but mastering it is a major milestone.'
  }
};

/* SVG fretboard constants */
var SVG_W        = 180;
var SVG_H        = 220;
var FRET_COUNT   = 4;
var STR_COUNT    = 6;
var MARGIN_LEFT  = 36;
var MARGIN_TOP   = 40;
var CELL_W       = (SVG_W - MARGIN_LEFT - 12) / (STR_COUNT - 1);
var CELL_H       = (SVG_H - MARGIN_TOP - 20) / FRET_COUNT;
var DOT_R        = 10;
var NS           = 'http://www.w3.org/2000/svg';

/** Create an SVG element with given attributes */
function svgEl(tag, attrs) {
  var el = document.createElementNS(NS, tag);
  Object.keys(attrs).forEach(function (k) { el.setAttribute(k, attrs[k]); });
  return el;
}

/**
 * Draw a fretboard chord diagram as an inline SVG.
 * @param {Object} chord - chord data object from CHORDS
 * @returns {SVGElement}
 */
function drawChordDiagram(chord) {
  var C_PRIMARY = '#C2692B';
  var C_DARK    = '#2C1F14';
  var C_MUTED   = '#7A6050';
  var C_BORDER  = '#DDD0C0';

  var svg = svgEl('svg', {
    width: SVG_W, height: SVG_H,
    viewBox: '0 0 ' + SVG_W + ' ' + SVG_H
  });

  // Nut (thick top bar)
  svg.appendChild(svgEl('rect', {
    x: MARGIN_LEFT, y: MARGIN_TOP - 6,
    width: (STR_COUNT - 1) * CELL_W, height: 6,
    fill: C_DARK, rx: 2
  }));

  // Fret lines (horizontal)
  for (var f = 0; f <= FRET_COUNT; f++) {
    var fy = MARGIN_TOP + f * CELL_H;
    svg.appendChild(svgEl('line', {
      x1: MARGIN_LEFT, y1: fy,
      x2: MARGIN_LEFT + (STR_COUNT - 1) * CELL_W, y2: fy,
      stroke: C_BORDER, 'stroke-width': 1
    }));
  }

  // String lines (vertical) + open / muted markers
  for (var s = 0; s < STR_COUNT; s++) {
    var sx = MARGIN_LEFT + s * CELL_W;
    var stringNum = STR_COUNT - s; // 6 = low E (left), 1 = high e (right)

    // Vertical string line
    svg.appendChild(svgEl('line', {
      x1: sx, y1: MARGIN_TOP,
      x2: sx, y2: MARGIN_TOP + FRET_COUNT * CELL_H,
      stroke: C_DARK,
      'stroke-width': (s === 0 || s === STR_COUNT - 1) ? 2 : 1.2
    }));

    // Open string  ○
    if (chord.openStrings.indexOf(stringNum) !== -1) {
      svg.appendChild(svgEl('circle', {
        cx: sx, cy: MARGIN_TOP - 16, r: 7,
        fill: 'none', stroke: C_DARK, 'stroke-width': 1.8
      }));
    }

    // Muted string  ×
    if (chord.mutedStrings.indexOf(stringNum) !== -1) {
      var d = 5.5;
      [[-1, -1], [1, -1]].forEach(function (dir) {
        svg.appendChild(svgEl('line', {
          x1: sx + dir[0] * d, y1: MARGIN_TOP - 16 - d,
          x2: sx - dir[0] * d, y2: MARGIN_TOP - 16 + d,
          stroke: C_MUTED, 'stroke-width': 2, 'stroke-linecap': 'round'
        }));
      });
    }
  }

  // Finger dots
  chord.positions.forEach(function (pos) {
    var xIdx = STR_COUNT - pos.string; // column index (0 = low E)
    var cx   = MARGIN_LEFT + xIdx * CELL_W;
    var cy   = MARGIN_TOP  + (pos.fret - 0.5) * CELL_H;

    // Dot
    svg.appendChild(svgEl('circle', { cx: cx, cy: cy, r: DOT_R, fill: C_PRIMARY }));

    // Finger number
    var txt = svgEl('text', {
      x: cx, y: cy + 4.5,
      'text-anchor': 'middle',
      fill: '#fff',
      'font-size': 11,
      'font-family': 'Inter, sans-serif',
      'font-weight': 600
    });
    txt.textContent = pos.finger;
    svg.appendChild(txt);
  });

  // Fret numbers on the left
  for (var fn = 1; fn <= FRET_COUNT; fn++) {
    var ty = MARGIN_TOP + (fn - 0.5) * CELL_H;
    var ftxt = svgEl('text', {
      x: MARGIN_LEFT - 10, y: ty + 4,
      'text-anchor': 'middle',
      fill: C_MUTED,
      'font-size': 10,
      'font-family': 'Inter, sans-serif'
    });
    ftxt.textContent = fn;
    svg.appendChild(ftxt);
  }

  return svg;
}

/**
 * Select and display a chord in the trainer.
 * @param {string} chordKey - key from CHORDS object (e.g. 'C', 'Em')
 */
function selectChord(chordKey) {
  var chord = CHORDS[chordKey];
  if (!chord) return;

  // Highlight the active button
  document.querySelectorAll('.chord-btn').forEach(function (btn) {
    btn.classList.toggle('active', btn.dataset.chord === chordKey);
  });

  // Render the SVG diagram
  var diagramWrap = document.getElementById('chordDiagram');
  diagramWrap.innerHTML = '';
  diagramWrap.appendChild(drawChordDiagram(chord));

  // Update text info
  document.getElementById('chordName').textContent    = chord.fullName;
  document.getElementById('chordFingers').textContent = chord.fingers;
  document.getElementById('chordFact').textContent    = chord.fact;

  // Re-trigger the fade-in animation
  var display = document.getElementById('chordDisplay');
  display.style.animation = 'none';
  void display.offsetHeight; // trigger reflow
  display.style.animation  = '';
}


/* ============================================================
   GUITAR QUIZ
   ============================================================ */

var QUESTIONS = [
  {
    q: 'How many strings does a standard guitar have?',
    options: ['4', '5', '6', '7'],
    answer: 2
  },
  {
    q: 'Which famous guitarist is widely known as the "King of the Blues"?',
    options: ['Eric Clapton', 'B.B. King', 'Jimi Hendrix', 'Chuck Berry'],
    answer: 1
  },
  {
    q: 'What is a "capo" used for on a guitar?',
    options: [
      'A finger-picking technique',
      'A device that clamps across the fretboard to raise the pitch',
      'A type of guitar strap',
      'A term for fast strumming'
    ],
    answer: 1
  },
  {
    q: 'Which guitar produces sound acoustically without any electronics?',
    options: ['Solid body electric', 'Semi-hollow electric', 'Classical / Acoustic', 'Resonator'],
    answer: 2
  },
  {
    q: 'What are the standard tuning notes of a guitar from lowest to highest string?',
    options: ['EADGBE', 'EBGDAE', 'DAEGBE', 'ABCDEF'],
    answer: 0
  },
  {
    q: 'What material are classical guitar strings traditionally made from?',
    options: ['Steel', 'Nylon', 'Bronze', 'Titanium'],
    answer: 1
  },
  {
    q: 'Jimi Hendrix famously played a right-handed guitar flipped upside-down for left-handed playing. True or false?',
    options: ['True', 'False', 'He always played right-handed', 'He only played bass guitar'],
    answer: 0
  },
  {
    q: 'What is a "barre chord"?',
    options: [
      'A chord played only on the top two strings',
      'A chord where one finger presses across all strings at one fret',
      'A chord that uses only open strings',
      'A Spanish term for a minor chord'
    ],
    answer: 1
  }
];

var quizState = { current: 0, score: 0, answered: false };

/** Reset quiz state and render the first question */
function startQuiz() {
  quizState = { current: 0, score: 0, answered: false };
  renderQuestion();
}

/** Render the current question */
function renderQuestion() {
  var q     = QUESTIONS[quizState.current];
  var total = QUESTIONS.length;

  // Update progress bar
  var pct = Math.round((quizState.current / total) * 100);
  document.getElementById('quizProgressFill').style.width = pct + '%';
  document.getElementById('quizProgressText').textContent =
    'Question ' + (quizState.current + 1) + ' of ' + total;

  // Render question text
  document.getElementById('quizQuestion').textContent = q.q;

  // Render answer buttons
  var optionsEl = document.getElementById('quizOptions');
  optionsEl.innerHTML = '';
  q.options.forEach(function (opt, idx) {
    var btn       = document.createElement('button');
    btn.className = 'quiz-option';
    btn.textContent = opt;
    btn.onclick   = function () { selectAnswer(idx); };
    optionsEl.appendChild(btn);
  });

  // Hide Next button; show question panel
  document.getElementById('quizNextBtn').style.display = 'none';
  document.getElementById('quizContent').style.display = 'block';
  document.getElementById('quizResult').style.display  = 'none';

  quizState.answered = false;
}

/**
 * Handle the player selecting an answer.
 * @param {number} idx - index of chosen option
 */
function selectAnswer(idx) {
  if (quizState.answered) return;
  quizState.answered = true;

  var correct = QUESTIONS[quizState.current].answer;
  var options = document.querySelectorAll('.quiz-option');

  options.forEach(function (btn, i) {
    btn.disabled = true;
    if (i === correct)              btn.classList.add('correct');
    if (i === idx && i !== correct) btn.classList.add('wrong');
  });

  if (idx === correct) quizState.score++;

  var nextBtn = document.getElementById('quizNextBtn');
  nextBtn.style.display = 'block';
  nextBtn.textContent   =
    quizState.current + 1 < QUESTIONS.length ? 'Next Question' : 'See Results';
}

/** Advance to the next question or show the result screen */
function nextQuestion() {
  quizState.current++;
  if (quizState.current < QUESTIONS.length) {
    renderQuestion();
  } else {
    showQuizResult();
  }
}

/** Display the score and save it to the leaderboard */
function showQuizResult() {
  document.getElementById('quizContent').style.display = 'none';
  document.getElementById('quizResult').style.display  = 'block';

  var total = QUESTIONS.length;
  var pct   = Math.round((quizState.score / total) * 100);

  document.getElementById('quizScoreDisplay').textContent = quizState.score + ' / ' + total;
  document.getElementById('quizProgressFill').style.width = '100%';
  document.getElementById('quizProgressText').textContent = 'Quiz Complete!';

  var msg = '';
  if (pct === 100)     msg = 'Perfect score! You are a true guitar master.';
  else if (pct >= 75)  msg = 'Excellent! You clearly know your guitar theory.';
  else if (pct >= 50)  msg = 'Good effort! Keep practicing and you will ace it.';
  else                 msg = 'Keep learning — every great guitarist started somewhere!';

  document.getElementById('quizMessage').textContent = msg;

  // Prompt for name and save to leaderboard
  var playerName = prompt('Enter your name for the leaderboard (or leave blank to skip):');
  if (playerName !== null) {
    saveScore(playerName || 'Anonymous', quizState.score, total, pct);
    renderLeaderboard();
  }
}

/* ── localStorage leaderboard ─────────────────────────────────────────────── */

/**
 * Save a quiz score to localStorage.
 * Keeps only the top 10 scores sorted by percentage.
 */
function saveScore(name, score, total, pct) {
  var scores = JSON.parse(localStorage.getItem('gj_leaderboard') || '[]');
  scores.push({
    name  : name.slice(0, 30),
    score : score,
    total : total,
    pct   : pct,
    date  : new Date().toLocaleDateString()
  });
  scores.sort(function (a, b) { return b.pct - a.pct || b.score - a.score; });
  scores.splice(10);
  localStorage.setItem('gj_leaderboard', JSON.stringify(scores));
}

/** Render the top-scores leaderboard table from localStorage */
function renderLeaderboard() {
  var scores = JSON.parse(localStorage.getItem('gj_leaderboard') || '[]');
  var tbody  = document.getElementById('leaderboardBody');
  if (!tbody) return;

  if (scores.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:20px;">No scores yet. Take the quiz to appear here!</td></tr>';
    return;
  }

  var rankClasses = ['gold', 'silver', 'bronze'];
  tbody.innerHTML = scores.map(function (s, i) {
    var rc = rankClasses[i] || '';
    return '<tr>' +
      '<td><span class="rank-badge ' + rc + '">' + (i + 1) + '</span></td>' +
      '<td>' + escHtml(s.name) + '</td>' +
      '<td>' + s.score + ' / ' + s.total + '</td>' +
      '<td><strong>' + s.pct + '%</strong></td>' +
      '</tr>';
  }).join('');
}

/** Escape HTML special characters to prevent XSS */
function escHtml(str) {
  return String(str)
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;');
}


/* ============================================================
   CONTACT FORM — client-side validation
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  var form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    var valid = true;

    /* Helper utilities */
    function showErr(errId, inputId, msg) {
      var errEl   = document.getElementById(errId);
      var inputEl = document.getElementById(inputId);
      if (errEl)   { errEl.textContent = msg; errEl.classList.add('show'); }
      if (inputEl) inputEl.classList.add('invalid');
      valid = false;
    }
    function clearErr(errId, inputId) {
      var errEl   = document.getElementById(errId);
      var inputEl = document.getElementById(inputId);
      if (errEl)   { errEl.textContent = ''; errEl.classList.remove('show'); }
      if (inputEl) inputEl.classList.remove('invalid');
    }

    // Clear previous errors
    clearErr('errName',    'contactName');
    clearErr('errEmail',   'contactEmail');
    clearErr('errMessage', 'contactMessage');

    // Validate Name
    var name = document.getElementById('contactName').value.trim();
    if (!name) {
      showErr('errName', 'contactName', 'Name is required.');
    } else if (name.length > 100) {
      showErr('errName', 'contactName', 'Name must be 100 characters or fewer.');
    }

    // Validate Email
    var email      = document.getElementById('contactEmail').value.trim();
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      showErr('errEmail', 'contactEmail', 'Email address is required.');
    } else if (!emailRegex.test(email)) {
      showErr('errEmail', 'contactEmail', 'Please enter a valid email address.');
    }

    // Validate Message
    var message = document.getElementById('contactMessage').value.trim();
    if (!message) {
      showErr('errMessage', 'contactMessage', 'Message is required.');
    } else if (message.length < 20) {
      showErr('errMessage', 'contactMessage',
        'Message must be at least 20 characters (currently ' + message.length + ').');
    } else if (message.length > 2000) {
      showErr('errMessage', 'contactMessage', 'Message must be 2,000 characters or fewer.');
    }

    // Block submission if any validation failed
    if (!valid) {
      e.preventDefault();
    }
  });

  // Live character counter for the message textarea
  var msgField = document.getElementById('contactMessage');
  var counter  = document.getElementById('msgCounter');
  if (msgField && counter) {
    msgField.addEventListener('input', function () {
      var len = msgField.value.length;
      counter.textContent = len + ' / 2000';
      counter.style.color = len < 20 ? 'var(--error)' : 'var(--text-muted)';
    });
  }
});
